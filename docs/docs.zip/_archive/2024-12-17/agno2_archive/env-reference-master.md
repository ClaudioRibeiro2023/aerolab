# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                                                                              ┃
# ┃   █████╗  ██████╗ ███╗   ██╗ ██████╗     ██████╗ ██╗      █████╗ ████████╗   ┃
# ┃  ██╔══██╗██╔════╝ ████╗  ██║██╔═══██╗    ██╔══██╗██║     ██╔══██╗╚══██╔══╝   ┃
# ┃  ███████║██║  ███╗██╔██╗ ██║██║   ██║    ██████╔╝██║     ███████║   ██║      ┃
# ┃  ██╔══██║██║   ██║██║╚██╗██║██║   ██║    ██╔═══╝ ██║     ██╔══██║   ██║      ┃
# ┃  ██║  ██║╚██████╔╝██║ ╚████║╚██████╔╝    ██║     ███████╗██║  ██║   ██║      ┃
# ┃  ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝     ╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝      ┃
# ┃                                                                              ┃
# ┃                    🤖 Multi-Agent Platform v3.0                              ┃
# ┃                    📅 Atualizado: 09/12/2025                                 ┃
# ┃                                                                              ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
#
# ┌──────────────────────────────────────────────────────────────────────────────┐
# │  📋 INSTRUÇÕES                                                               │
# ├──────────────────────────────────────────────────────────────────────────────┤
# │  1. Copie este arquivo para .env                                             │
# │  2. Preencha APENAS as chaves dos serviços que você vai usar                 │
# │  3. Chaves vazias = integração desabilitada (não causa erro)                 │
# │  4. ⚠️  NUNCA commite este arquivo no Git                                    │
# └──────────────────────────────────────────────────────────────────────────────┘
#
# ┌──────────────────────────────────────────────────────────────────────────────┐
# │  🐳 PORTAS DOCKER (série 4xxx)                                               │
# ├──────────────────────────────────────────────────────────────────────────────┤
# │  Frontend ........... http://localhost:4001                                  │
# │  Backend ............ http://localhost:4000                                  │
# │  ChromaDB ........... http://localhost:4002                                  │
# │  Ollama ............. http://localhost:4003                                  │
# │  Redis .............. localhost:4004                                         │
# └──────────────────────────────────────────────────────────────────────────────┘



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🧠  PROVEDORES DE LLM (Modelos de Linguagem)                               ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  OpenAI                                                                     │
# │  ├─ Modelos: GPT-4o, GPT-4 Turbo, GPT-3.5, Embeddings                       │
# │  ├─ 📍 https://platform.openai.com/api-keys                                 │
# │  ├─ 💰 ~$0.01-0.03/1K tokens                                                │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Chat completions (conversas, assistentes)                             │
# │  │  • Text embeddings (vetorização para RAG)                                │
# │  │  • Image generation (DALL-E 3)                                           │
# │  │  • Vision (análise de imagens)                                           │
# │  │  • Function calling (execução de ferramentas)                            │
# │  │  • Fine-tuning de modelos customizados                                   │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
OPENAI_API_KEY=
OPENAI_ORG_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Anthropic                                                                  │
# │  ├─ Modelos: Claude 3.5 Sonnet, Claude 3 Opus                               │
# │  ├─ 📍 https://console.anthropic.com/                                       │
# │  ├─ 💰 ~$0.008-0.024/1K tokens                                              │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Contexto longo (200K tokens)                                          │
# │  │  • Análise de documentos extensos                                        │
# │  │  • Raciocínio complexo e nuançado                                        │
# │  │  • Código e debugging avançado                                           │
# │  │  • Vision (análise de imagens)                                           │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
ANTHROPIC_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Groq  ⭐ RECOMENDADO                                                       │
# │  ├─ Modelos: Llama 3.3 70B, Mixtral 8x7B                                    │
# │  ├─ 📍 https://console.groq.com/keys                                        │
# │  ├─ 💰 GRATUITO (14,400 req/dia)                                            │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Inferência ultra-rápida (LPU hardware)                                │
# │  │  • Modelos open-source (Llama, Mixtral)                                  │
# │  │  • Ideal para prototipagem e testes                                      │
# │  │  • Baixa latência para chatbots                                          │
# │  │  • Streaming de respostas                                                │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
GROQ_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Google AI                                                                  │
# │  ├─ Modelos: Gemini Pro, Gemini Ultra                                       │
# │  ├─ 📍 https://makersuite.google.com/app/apikey                             │
# │  ├─ 💰 Free tier generoso                                                   │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Multimodal (texto, imagem, áudio, vídeo)                              │
# │  │  • Contexto de 1M tokens (Gemini 1.5)                                    │
# │  │  • Integração com Google Search                                          │
# │  │  • Code generation                                                       │
# │  │  • Grounding com fontes web                                              │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
GOOGLE_API_KEY=
GOOGLE_PROJECT_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Azure OpenAI                                                               │
# │  └─ 📍 https://portal.azure.com/                                            │
# └─────────────────────────────────────────────────────────────────────────────┘
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_DEPLOYMENT=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Cohere                                                                     │
# │  ├─ Modelos: Embeddings, Rerank                                             │
# │  └─ 📍 https://dashboard.cohere.com/api-keys                                │
# └─────────────────────────────────────────────────────────────────────────────┘
COHERE_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Mistral AI                                                                 │
# │  └─ 📍 https://console.mistral.ai/                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
MISTRAL_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Ollama (LLMs Locais)                                                       │
# │  ├─ 📍 https://ollama.ai/                                                   │
# │  └─ 💰 GRATUITO (roda local)                                                │
# └─────────────────────────────────────────────────────────────────────────────┘
OLLAMA_BASE_URL=http://localhost:11434



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🔍  FERRAMENTAS DE PESQUISA                                                ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Tavily Search  ⭐ RECOMENDADO                                              │
# │  ├─ Pesquisa web otimizada para AI                                          │
# │  ├─ 📍 https://tavily.com/                                                  │
# │  ├─ 💰 Free tier (1000 buscas/mês)                                          │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Pesquisa web em tempo real                                            │
# │  │  • Resultados estruturados para LLMs                                     │
# │  │  • Extração automática de conteúdo relevante                             │
# │  │  • Filtros por data, domínio, tipo                                       │
# │  │  • Ideal para agentes que precisam de dados atuais                       │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
TAVILY_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Perplexity AI                                                              │
# │  ├─ Pesquisa avançada com LLM integrado                                     │
# │  ├─ 📍 https://www.perplexity.ai/settings/api                               │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Pesquisa + síntese com citações                                       │
# │  │  • Respostas baseadas em fontes verificadas                              │
# │  │  • Modelo Sonar para pesquisa especializada                              │
# │  │  • Follow-up questions automáticas                                       │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
PERPLEXITY_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  SerpAPI                                                                    │
# │  ├─ Google Search, Bing, Yahoo, etc.                                        │
# │  └─ 📍 https://serpapi.com/                                                 │
# └─────────────────────────────────────────────────────────────────────────────┘
SERPAPI_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Serper                                                                     │
# │  ├─ Google Search API                                                       │
# │  └─ 📍 https://serper.dev/                                                  │
# └─────────────────────────────────────────────────────────────────────────────┘
SERPER_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Exa AI                                                                     │
# │  ├─ Pesquisa semântica                                                      │
# │  └─ 📍 https://exa.ai/                                                      │
# └─────────────────────────────────────────────────────────────────────────────┘
EXA_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Firecrawl (Web Scraper)                                                    │
# │  ├─ Extração de dados de páginas web                                        │
# │  └─ 📍 https://firecrawl.dev/                                               │
# └─────────────────────────────────────────────────────────────────────────────┘
FIRECRAWL_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Browserless                                                                │
# │  ├─ Headless Browser para scraping                                          │
# │  └─ 📍 https://browserless.io/                                              │
# └─────────────────────────────────────────────────────────────────────────────┘
BROWSERLESS_API_KEY=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🛠️  DEVOPS & DEPLOY                                                        ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  GitHub                                                                     │
# │  ├─ Repositórios, Issues, Pull Requests                                     │
# │  ├─ 📍 https://github.com/settings/tokens                                   │
# │  └─ Escopos: repo, read:org, read:user                                      │
# └─────────────────────────────────────────────────────────────────────────────┘
GITHUB_TOKEN=
GITHUB_USERNAME=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  GitLab                                                                     │
# │  └─ 📍 https://gitlab.com/-/user_settings/personal_access_tokens            │
# └─────────────────────────────────────────────────────────────────────────────┘
GITLAB_TOKEN=
GITLAB_URL=https://gitlab.com

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Netlify                                                                    │
# │  ├─ Deploy de sites estáticos e frontend                                    │
# │  └─ 📍 https://app.netlify.com/user/applications                            │
# └─────────────────────────────────────────────────────────────────────────────┘
NETLIFY_AUTH_TOKEN=
NETLIFY_SITE_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Vercel                                                                     │
# │  ├─ Deploy de apps Next.js, React, etc.                                     │
# │  └─ 📍 https://vercel.com/account/tokens                                    │
# └─────────────────────────────────────────────────────────────────────────────┘
VERCEL_TOKEN=
VERCEL_ORG_ID=
VERCEL_PROJECT_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Railway                                                                    │
# │  ├─ Deploy de backends e databases                                          │
# │  └─ 📍 https://railway.app/account/tokens                                   │
# └─────────────────────────────────────────────────────────────────────────────┘
RAILWAY_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Docker Hub                                                                 │
# │  └─ 📍 https://hub.docker.com/settings/security                             │
# └─────────────────────────────────────────────────────────────────────────────┘
DOCKER_USERNAME=
DOCKER_PASSWORD=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🗄️  DATABASES & STORAGE                                                    ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Supabase  ⭐ RECOMENDADO                                                   │
# │  ├─ PostgreSQL + Auth + Storage + Realtime                                  │
# │  ├─ 📍 https://supabase.com/dashboard/project/_/settings/api                │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Banco PostgreSQL gerenciado                                           │
# │  │  • Autenticação (email, social, magic link)                              │
# │  │  • Storage para arquivos (S3-compatible)                                 │
# │  │  • Realtime subscriptions (WebSocket)                                    │
# │  │  • Edge Functions (serverless)                                           │
# │  │  • Row Level Security (RLS)                                              │
# │  │  • API REST e GraphQL automáticas                                        │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
SUPABASE_URL=
SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Neon                                                                       │
# │  ├─ PostgreSQL Serverless                                                   │
# │  └─ 📍 https://console.neon.tech/                                           │
# └─────────────────────────────────────────────────────────────────────────────┘
NEON_DATABASE_URL=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  PlanetScale                                                                │
# │  ├─ MySQL Serverless                                                        │
# │  └─ 📍 https://planetscale.com/                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
PLANETSCALE_DATABASE_URL=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  MongoDB Atlas                                                              │
# │  └─ 📍 https://cloud.mongodb.com/                                           │
# └─────────────────────────────────────────────────────────────────────────────┘
MONGODB_URI=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Upstash                                                                    │
# │  ├─ Redis Serverless                                                        │
# │  └─ 📍 https://console.upstash.com/                                         │
# └─────────────────────────────────────────────────────────────────────────────┘
UPSTASH_REDIS_URL=
UPSTASH_REDIS_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Pinecone                                                                   │
# │  ├─ Vector Database para RAG                                                │
# │  └─ 📍 https://app.pinecone.io/                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
PINECONE_API_KEY=
PINECONE_ENVIRONMENT=
PINECONE_INDEX=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Weaviate                                                                   │
# │  ├─ Vector Database                                                         │
# │  └─ 📍 https://console.weaviate.cloud/                                      │
# └─────────────────────────────────────────────────────────────────────────────┘
WEAVIATE_URL=
WEAVIATE_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Qdrant                                                                     │
# │  ├─ Vector Database                                                         │
# │  └─ 📍 https://cloud.qdrant.io/                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
QDRANT_URL=
QDRANT_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Neo4j                                                                      │
# │  ├─ Graph Database para GraphRAG                                            │
# │  └─ 📍 https://neo4j.com/cloud/aura/                                        │
# └─────────────────────────────────────────────────────────────────────────────┘
NEO4J_URI=
NEO4J_USERNAME=
NEO4J_PASSWORD=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  AWS S3                                                                     │
# │  ├─ Object Storage                                                          │
# │  └─ 📍 https://console.aws.amazon.com/                                      │
# └─────────────────────────────────────────────────────────────────────────────┘
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_REGION=us-east-1
AWS_S3_BUCKET=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Cloudflare R2                                                              │
# │  ├─ S3-compatible Storage                                                   │
# │  └─ 📍 https://dash.cloudflare.com/                                         │
# └─────────────────────────────────────────────────────────────────────────────┘
CLOUDFLARE_R2_ACCESS_KEY=
CLOUDFLARE_R2_SECRET_KEY=
CLOUDFLARE_R2_BUCKET=
CLOUDFLARE_ACCOUNT_ID=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   💬  COMUNICAÇÃO                                                            ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Slack                                                                      │
# │  ├─ Mensagens, canais, notificações                                         │
# │  ├─ 📍 https://api.slack.com/apps                                           │
# │  ├─ Escopos: chat:write, channels:read, users:read                          │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Enviar mensagens para canais/DMs                                      │
# │  │  • Criar e gerenciar canais                                              │
# │  │  • Receber comandos slash (/)                                            │
# │  │  • Webhooks para notificações                                            │
# │  │  • Reagir a mensagens                                                    │
# │  │  • Upload de arquivos                                                    │
# │  │  • Bots interativos com botões/menus                                     │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
SLACK_BOT_TOKEN=
SLACK_SIGNING_SECRET=
SLACK_APP_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Discord                                                                    │
# │  └─ 📍 https://discord.com/developers/applications                          │
# └─────────────────────────────────────────────────────────────────────────────┘
DISCORD_BOT_TOKEN=
DISCORD_CLIENT_ID=
DISCORD_CLIENT_SECRET=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Telegram                                                                   │
# │  └─ 📍 https://t.me/BotFather                                               │
# └─────────────────────────────────────────────────────────────────────────────┘
TELEGRAM_BOT_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  WhatsApp Business API                                                      │
# │  ├─ 📍 Twilio: https://console.twilio.com/                                  │
# │  └─ 📍 Meta: https://developers.facebook.com/                               │
# └─────────────────────────────────────────────────────────────────────────────┘
WHATSAPP_API_TOKEN=
WHATSAPP_PHONE_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Twilio                                                                     │
# │  ├─ SMS, WhatsApp, Voice                                                    │
# │  └─ 📍 https://console.twilio.com/                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  SendGrid                                                                   │
# │  ├─ Email transacional                                                      │
# │  └─ 📍 https://app.sendgrid.com/settings/api_keys                           │
# └─────────────────────────────────────────────────────────────────────────────┘
SENDGRID_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Resend                                                                     │
# │  ├─ Email moderno para developers                                           │
# │  └─ 📍 https://resend.com/api-keys                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
RESEND_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Gmail API                                                                  │
# │  └─ 📍 https://console.cloud.google.com/apis/credentials                    │
# └─────────────────────────────────────────────────────────────────────────────┘
GMAIL_CLIENT_ID=
GMAIL_CLIENT_SECRET=
GMAIL_REFRESH_TOKEN=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   📅  PRODUTIVIDADE                                                          ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Notion                                                                     │
# │  ├─ Páginas, Databases, Wikis                                               │
# │  ├─ 📍 https://www.notion.so/my-integrations                                │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Criar/editar páginas e blocos                                         │
# │  │  • CRUD em databases (tabelas)                                           │
# │  │  • Busca em workspace                                                    │
# │  │  • Gerenciar propriedades e relações                                     │
# │  │  • Ideal para knowledge base de agentes                                  │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
NOTION_API_KEY=
NOTION_DATABASE_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Google Calendar                                                            │
# │  ├─ Agenda e gerenciamento de eventos                                       │
# │  ├─ 📍 https://console.cloud.google.com/apis/credentials                    │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Criar/editar/deletar eventos                                          │
# │  │  • Verificar disponibilidade                                             │
# │  │  • Convidar participantes                                                │
# │  │  • Listar calendários e eventos                                          │
# │  │  • Definir lembretes e recorrência                                       │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
GOOGLE_CALENDAR_CLIENT_ID=
GOOGLE_CALENDAR_CLIENT_SECRET=
GOOGLE_CALENDAR_REFRESH_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Zapier                                                                     │
# │  ├─ Conecta 5000+ apps via webhooks                                         │
# │  ├─ 📍 https://zapier.com/app/developer                                     │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Triggar automações em 5000+ apps                                      │
# │  │  • Natural Language Actions (NLA)                                        │
# │  │  • Webhooks de entrada e saída                                           │
# │  │  • Permite agentes acionarem workflows                                   │
# │  │  • Integração com CRMs, email, planilhas                                 │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
ZAPIER_WEBHOOK_URL=
ZAPIER_NLA_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Make (Integromat)                                                          │
# │  ├─ Automações visuais                                                      │
# │  └─ 📍 https://www.make.com/                                                │
# └─────────────────────────────────────────────────────────────────────────────┘
MAKE_WEBHOOK_URL=
MAKE_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Airtable                                                                   │
# │  ├─ Spreadsheet + Database                                                  │
# │  └─ 📍 https://airtable.com/create/tokens                                   │
# └─────────────────────────────────────────────────────────────────────────────┘
AIRTABLE_API_KEY=
AIRTABLE_BASE_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Linear                                                                     │
# │  ├─ Project Management moderno                                              │
# │  └─ 📍 https://linear.app/settings/api                                      │
# └─────────────────────────────────────────────────────────────────────────────┘
LINEAR_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Jira                                                                       │
# │  ├─ Project Management empresarial                                          │
# │  └─ 📍 https://id.atlassian.com/manage-profile/security/api-tokens          │
# └─────────────────────────────────────────────────────────────────────────────┘
JIRA_API_TOKEN=
JIRA_EMAIL=
JIRA_DOMAIN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Trello                                                                     │
# │  └─ 📍 https://trello.com/power-ups/admin                                   │
# └─────────────────────────────────────────────────────────────────────────────┘
TRELLO_API_KEY=
TRELLO_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Asana                                                                      │
# │  └─ 📍 https://app.asana.com/0/developer-console                            │
# └─────────────────────────────────────────────────────────────────────────────┘
ASANA_ACCESS_TOKEN=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   💰  FINANCEIRO & PAGAMENTOS                                                ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Stripe                                                                     │
# │  ├─ Pagamentos, Subscriptions, Checkout                                     │
# │  └─ 📍 https://dashboard.stripe.com/apikeys                                 │
# └─────────────────────────────────────────────────────────────────────────────┘
STRIPE_SECRET_KEY=
STRIPE_PUBLISHABLE_KEY=
STRIPE_WEBHOOK_SECRET=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  PayPal                                                                     │
# │  └─ 📍 https://developer.paypal.com/                                        │
# └─────────────────────────────────────────────────────────────────────────────┘
PAYPAL_CLIENT_ID=
PAYPAL_CLIENT_SECRET=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Mercado Pago (Brasil)                                                      │
# │  └─ 📍 https://www.mercadopago.com.br/developers/panel                      │
# └─────────────────────────────────────────────────────────────────────────────┘
MERCADOPAGO_ACCESS_TOKEN=
MERCADOPAGO_PUBLIC_KEY=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   📊  ANALYTICS & MONITORAMENTO                                              ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Langfuse  ⭐ RECOMENDADO                                                   │
# │  ├─ LLM Analytics, Tracing, Debugging                                       │
# │  └─ 📍 https://langfuse.com/                                                │
# └─────────────────────────────────────────────────────────────────────────────┘
LANGFUSE_PUBLIC_KEY=
LANGFUSE_SECRET_KEY=
LANGFUSE_HOST=https://cloud.langfuse.com

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  LangSmith                                                                  │
# │  ├─ LangChain observability                                                 │
# │  └─ 📍 https://smith.langchain.com/                                         │
# └─────────────────────────────────────────────────────────────────────────────┘
LANGSMITH_API_KEY=
LANGSMITH_PROJECT=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Sentry  ✅ CONFIGURADA                                                     │
# │  ├─ Error Tracking & Performance Monitoring                                 │
# │  ├─ 📍 https://sentry.io/settings/account/api/auth-tokens/                  │
# │  │                                                                          │
# │  │  � FUNCIONALIDADES:                                                     │
# │  │  • Captura automática de erros e exceções                                │
# │  │  • Stack traces com contexto de código                                   │
# │  │  • Performance monitoring (transações)                                   │
# │  │  • Release tracking e source maps                                        │
# │  │  • Alertas e notificações configuráveis                                  │
# │  │  • Integração com GitHub/GitLab                                          │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
NEXT_PUBLIC_SENTRY_DSN="https://401ae6d084e41e4a8e9f0fd3d71710cc@o4510502722142208.ingest.us.sentry.io/4510502738460672"
SENTRY_AUTH_TOKEN="<REDACTED>"
SENTRY_ORG="aero-engenharia"
SENTRY_PROJECT="techdengue-dashboard"

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  PostHog  ✅ CONFIGURADA                                                    │
# │  ├─ Product Analytics & Session Recording                                   │
# │  ├─ 📍 https://app.posthog.com/project/settings                             │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Eventos de usuário e conversões                                       │
# │  │  • Session replay (gravação de sessões)                                  │
# │  │  • Feature flags e A/B testing                                           │
# │  │  • Funnels e análise de retenção                                         │
# │  │  • Heatmaps e análise de comportamento                                   │
# │  │  • Integração com Slack, Zapier                                          │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
NEXT_PUBLIC_POSTHOG_KEY="phc_dWOtEa6gskrHxGRhVjzAxnqymigaEDpxwVBVcTAnWLY"
NEXT_PUBLIC_POSTHOG_HOST="https://app.posthog.com"

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Google Analytics  ✅ CONFIGURADA                                           │
# │  ├─ Web Analytics (GA4)                                                     │
# │  ├─ 📍 https://analytics.google.com/                                        │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Pageviews e sessões de usuários                                       │
# │  │  • Eventos personalizados                                                │
# │  │  • Análise de tráfego e aquisição                                        │
# │  │  • Funis de conversão                                                    │
# │  │  • Relatórios em tempo real                                              │
# │  │  • Integração com Google Ads                                             │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
NEXT_PUBLIC_GA_MEASUREMENT_ID="G-YYSPNFMHSW"

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Mixpanel                                                                   │
# │  └─ 📍 https://mixpanel.com/settings/project                                │
# └─────────────────────────────────────────────────────────────────────────────┘
MIXPANEL_TOKEN=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🎨  MÍDIA & AI TOOLS                                                       ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Stability AI                                                               │
# │  ├─ Geração de imagens (Stable Diffusion)                                   │
# │  └─ 📍 https://platform.stability.ai/account/keys                           │
# └─────────────────────────────────────────────────────────────────────────────┘
STABILITY_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Replicate                                                                  │
# │  ├─ Modelos AI on-demand                                                    │
# │  └─ 📍 https://replicate.com/account/api-tokens                             │
# └─────────────────────────────────────────────────────────────────────────────┘
REPLICATE_API_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  ElevenLabs                                                                 │
# │  ├─ Text-to-Speech realista                                                 │
# │  └─ 📍 https://elevenlabs.io/                                               │
# └─────────────────────────────────────────────────────────────────────────────┘
ELEVENLABS_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  AssemblyAI                                                                 │
# │  ├─ Speech-to-Text                                                          │
# │  └─ 📍 https://www.assemblyai.com/dashboard/                                │
# └─────────────────────────────────────────────────────────────────────────────┘
ASSEMBLYAI_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Deepgram                                                                   │
# │  ├─ Speech-to-Text em tempo real                                            │
# │  └─ 📍 https://console.deepgram.com/                                        │
# └─────────────────────────────────────────────────────────────────────────────┘
DEEPGRAM_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Unstructured.io                                                            │
# │  ├─ Processamento de documentos (PDF, DOCX, etc.)                           │
# │  └─ 📍 https://unstructured.io/                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
UNSTRUCTURED_API_KEY=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🗺️  GEOLOCALIZAÇÃO, CLIMA & MAPAS                                          ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Mapbox  ✅ CONFIGURADA                                                     │
# │  ├─ Mapas, geocoding, rotas, navegação                                      │
# │  ├─ 📍 https://account.mapbox.com/access-tokens/                            │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Mapas interativos (2D/3D)                                             │
# │  │  • Geocoding (endereço → coordenadas)                                    │
# │  │  • Rotas e navegação turn-by-turn                                        │
# │  │  • Estilos customizáveis (light, dark, satellite)                        │
# │  │  • Heatmaps e visualização de dados                                      │
# │  │  • Tilesets e datasets personalizados                                    │
# │  │                                                                          │
# │  │  📐 Estilos disponíveis:                                                 │
# │  │  • mapbox://styles/mapbox/streets-v12                                    │
# │  │  • mapbox://styles/mapbox/light-v11                                      │
# │  │  • mapbox://styles/mapbox/dark-v11                                       │
# │  │  • mapbox://styles/mapbox/satellite-streets-v12                          │
# │  │  • mapbox://styles/mapbox/outdoors-v12                                   │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
MAPBOX_API_KEY="pk.eyJ1IjoiYWVyb2Nsb3VkIiwiYSI6ImNtaWVvZzVqeTA1aXozZXBzMXNxZWo0ZnEifQ.KwMXCX8GBnQKaTaea2CWkA"
NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN="pk.eyJ1IjoiYWVyb2Nsb3VkIiwiYSI6ImNtaWVvZzVqeTA1aXozZXBzMXNxZWo0ZnEifQ.KwMXCX8GBnQKaTaea2CWkA"
NEXT_PUBLIC_MAPBOX_STYLE="mapbox://styles/mapbox/light-v11"
# Configurações avançadas do mapa
NEXT_PUBLIC_MAPBOX_DEFAULT_ZOOM="5"
NEXT_PUBLIC_MAPBOX_DEFAULT_CENTER_LAT="-16.6869"
NEXT_PUBLIC_MAPBOX_DEFAULT_CENTER_LNG="-49.2646"

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Google Maps                                                                │
# │  ├─ Mapas, Places, Directions, Geocoding                                    │
# │  ├─ 📍 https://console.cloud.google.com/apis/credentials                    │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Mapas embed e JavaScript API                                          │
# │  │  • Places API (busca de locais)                                          │
# │  │  • Directions API (rotas)                                                │
# │  │  • Distance Matrix (cálculo de distâncias)                               │
# │  │  • Street View                                                           │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
# GOOGLE_MAPS_API_KEY="AIzaSyDCjlr3Kwb5J62cxmUJYlHPriumg2Nt64E"
# GOOGLE_MAPS_MAP_ID="58de4f23a2549592a27c73a2"
GOOGLE_MAPS_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  OpenWeatherMap  ✅ CONFIGURADA                                             │
# │  ├─ Clima atual, previsão, alertas                                          │
# │  ├─ 📍 https://openweathermap.org/api                                       │
# │  ├─ 💰 Free tier (1000 calls/dia)                                           │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Clima atual por coordenadas/cidade                                    │
# │  │  • Previsão 5 dias / 3 horas                                             │
# │  │  • Alertas meteorológicos                                                │
# │  │  • Dados históricos                                                      │
# │  │  • Mapas de precipitação, temperatura                                    │
# │  │  • Air Quality Index (AQI)                                               │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
OPENWEATHERMAP_API_KEY="0d993e8b059135c9548085a50ff48f68"
NEXT_PUBLIC_OPENWEATHER_API_KEY="0d993e8b059135c9548085a50ff48f68"
NEXT_PUBLIC_OPENWEATHER_BASE_URL="https://api.openweathermap.org/data/2.5"
NEXT_PUBLIC_OPENWEATHER_UNITS="metric"

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  WeatherAPI                                                                 │
# │  ├─ Alternativa ao OpenWeather                                              │
# │  └─ 📍 https://www.weatherapi.com/                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
WEATHERAPI_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Tomorrow.io (ex-Climacell)                                                 │
# │  ├─ Clima avançado, micro-clima                                             │
# │  └─ 📍 https://www.tomorrow.io/                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
TOMORROW_API_KEY=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🇧🇷  APIS BRASILEIRAS (Dados Públicos)                                      ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  IBGE  ✅ CONFIGURADA                                                       │
# │  ├─ Dados geográficos, demográficos, econômicos                             │
# │  ├─ 📍 https://servicodados.ibge.gov.br/api/docs                            │
# │  ├─ 💰 GRATUITO (sem autenticação)                                          │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Estados, municípios, regiões do Brasil                                │
# │  │  • Dados do Censo demográfico                                            │
# │  │  • Indicadores econômicos (PIB, inflação)                                │
# │  │  • Mapas e malhas territoriais                                           │
# │  │  • Séries históricas de população                                        │
# │  │  • Agregados estatísticos (v3)                                           │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
NEXT_PUBLIC_IBGE_API_URL="https://servicodados.ibge.gov.br/api"
NEXT_PUBLIC_IBGE_LOCALIDADES_URL="https://servicodados.ibge.gov.br/api/v1/localidades"
NEXT_PUBLIC_IBGE_AGREGADOS_URL="https://servicodados.ibge.gov.br/api/v3/agregados"

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  InfoDengue  ✅ CONFIGURADA                                                 │
# │  ├─ Dados epidemiológicos (Dengue, Zika, Chikungunya)                       │
# │  ├─ 📍 https://info.dengue.mat.br/api                                       │
# │  ├─ 💰 GRATUITO                                                             │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Casos de arboviroses por município                                    │
# │  │  • Alertas epidemiológicos                                               │
# │  │  • Séries temporais de incidência                                        │
# │  │  • Dados de temperatura e precipitação                                   │
# │  │  • Previsões de surtos                                                   │
# │  │                                                                          │
# │  │  📝 Endpoint exemplo:                                                    │
# │  │  /api/alertcity?geocode={geocode}&disease={disease}&format=json          │
# │  │  &ew_start={ew}&ew_end={ew}&ey_start={year}&ey_end={year}                │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
NEXT_PUBLIC_INFODENGUE_API_URL="https://info.dengue.mat.br/api"

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Banco Central do Brasil                                                    │
# │  ├─ Cotações, índices econômicos, SELIC, IPCA                               │
# │  ├─ 📍 https://dadosabertos.bcb.gov.br/                                     │
# │  ├─ 💰 GRATUITO (sem autenticação)                                          │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Taxa SELIC e CDI                                                      │
# │  │  • Cotação do dólar (PTAX)                                               │
# │  │  • IPCA, IGP-M, inflação                                                 │
# │  │  • Séries temporais econômicas                                           │
# │  │  • Dados de instituições financeiras                                     │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
BCB_API_URL=https://api.bcb.gov.br

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  ViaCEP                                                                     │
# │  ├─ Consulta de CEP gratuita                                                │
# │  ├─ 📍 https://viacep.com.br/                                               │
# │  └─ 💰 GRATUITO                                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
VIACEP_API_URL=https://viacep.com.br/ws

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Brasil API                                                                 │
# │  ├─ CEP, CNPJ, Bancos, Feriados, DDD, ISBN, etc.                            │
# │  ├─ 📍 https://brasilapi.com.br/                                            │
# │  └─ 💰 GRATUITO                                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
BRASIL_API_URL=https://brasilapi.com.br/api

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Receita Federal (CNPJ)                                                     │
# │  ├─ Consulta de empresas                                                    │
# │  └─ 📍 https://www.receitaws.com.br/                                        │
# └─────────────────────────────────────────────────────────────────────────────┘
RECEITAWS_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Portal da Transparência                                                    │
# │  ├─ Gastos públicos, servidores, convênios                                  │
# │  ├─ 📍 https://api.portaldatransparencia.gov.br/                            │
# │  └─ 📍 Cadastro: https://api.portaldatransparencia.gov.br/swagger-ui.html   │
# └─────────────────────────────────────────────────────────────────────────────┘
PORTAL_TRANSPARENCIA_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  DataSUS / OpenDataSUS                                                      │
# │  ├─ Dados de saúde pública                                                  │
# │  └─ 📍 https://opendatasus.saude.gov.br/                                    │
# └─────────────────────────────────────────────────────────────────────────────┘
DATASUS_API_URL=https://imunizacao-es.saude.gov.br



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   📰  NOTÍCIAS & CONTEÚDO                                                    ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  NewsAPI                                                                    │
# │  ├─ Notícias de 80.000+ fontes                                              │
# │  ├─ 📍 https://newsapi.org/                                                 │
# │  └─ 💰 Free tier (100 req/dia)                                              │
# └─────────────────────────────────────────────────────────────────────────────┘
NEWSAPI_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  GNews                                                                      │
# │  ├─ Agregador de notícias                                                   │
# │  └─ 📍 https://gnews.io/                                                    │
# └─────────────────────────────────────────────────────────────────────────────┘
GNEWS_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  The Guardian                                                               │
# │  ├─ Notícias internacionais                                                 │
# │  └─ 📍 https://open-platform.theguardian.com/                               │
# └─────────────────────────────────────────────────────────────────────────────┘
GUARDIAN_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Reddit                                                                     │
# │  ├─ Posts, comentários, comunidades                                         │
# │  └─ 📍 https://www.reddit.com/prefs/apps                                    │
# └─────────────────────────────────────────────────────────────────────────────┘
REDDIT_CLIENT_ID=
REDDIT_CLIENT_SECRET=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Twitter/X                                                                  │
# │  ├─ Posts, trends, pesquisa                                                 │
# │  └─ 📍 https://developer.twitter.com/                                       │
# └─────────────────────────────────────────────────────────────────────────────┘
TWITTER_API_KEY=
TWITTER_API_SECRET=
TWITTER_BEARER_TOKEN=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  YouTube Data API                                                           │
# │  ├─ Vídeos, canais, playlists, comentários                                  │
# │  └─ 📍 https://console.cloud.google.com/apis/credentials                    │
# └─────────────────────────────────────────────────────────────────────────────┘
YOUTUBE_API_KEY=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🌐  TRADUÇÃO & LINGUAGEM                                                   ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  DeepL                                                                      │
# │  ├─ Tradução de alta qualidade                                              │
# │  ├─ 📍 https://www.deepl.com/pro-api                                        │
# │  └─ 💰 Free tier (500K chars/mês)                                           │
# └─────────────────────────────────────────────────────────────────────────────┘
DEEPL_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Google Translate                                                           │
# │  └─ 📍 https://console.cloud.google.com/apis/credentials                    │
# └─────────────────────────────────────────────────────────────────────────────┘
GOOGLE_TRANSLATE_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  LibreTranslate                                                             │
# │  ├─ Tradução open-source (self-hosted ou API)                               │
# │  └─ 📍 https://libretranslate.com/                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
LIBRETRANSLATE_API_KEY=
LIBRETRANSLATE_URL=https://libretranslate.com



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   💹  FINANÇAS & MERCADO                                                     ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Alpha Vantage                                                              │
# │  ├─ Ações, forex, crypto, indicadores                                       │
# │  ├─ 📍 https://www.alphavantage.co/support/#api-key                         │
# │  └─ 💰 Free tier (5 calls/min)                                              │
# └─────────────────────────────────────────────────────────────────────────────┘
ALPHA_VANTAGE_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Polygon.io                                                                 │
# │  ├─ Dados de mercado em tempo real                                          │
# │  └─ 📍 https://polygon.io/                                                  │
# └─────────────────────────────────────────────────────────────────────────────┘
POLYGON_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  CoinGecko                                                                  │
# │  ├─ Dados de criptomoedas                                                   │
# │  ├─ 📍 https://www.coingecko.com/en/api                                     │
# │  └─ 💰 Free tier generoso                                                   │
# └─────────────────────────────────────────────────────────────────────────────┘
COINGECKO_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Exchange Rate API                                                          │
# │  ├─ Cotações de moedas                                                      │
# │  └─ 📍 https://www.exchangerate-api.com/                                    │
# └─────────────────────────────────────────────────────────────────────────────┘
EXCHANGERATE_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Finnhub                                                                    │
# │  ├─ Dados financeiros, notícias, sentimento                                 │
# │  └─ 📍 https://finnhub.io/                                                  │
# └─────────────────────────────────────────────────────────────────────────────┘
FINNHUB_API_KEY=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🏥  SAÚDE & MEDICINA                                                       ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  PubMed / NCBI                                                              │
# │  ├─ Artigos científicos e médicos                                           │
# │  ├─ 📍 https://www.ncbi.nlm.nih.gov/home/develop/api/                       │
# │  └─ 💰 GRATUITO                                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
NCBI_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  OpenFDA                                                                    │
# │  ├─ Medicamentos, eventos adversos, recalls                                 │
# │  └─ 📍 https://open.fda.gov/apis/                                           │
# └─────────────────────────────────────────────────────────────────────────────┘
OPENFDA_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Anvisa (Brasil)                                                            │
# │  ├─ Medicamentos registrados no Brasil                                      │
# │  └─ 📍 https://consultas.anvisa.gov.br/                                     │
# └─────────────────────────────────────────────────────────────────────────────┘
ANVISA_API_URL=https://consultas.anvisa.gov.br/api



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   📚  CONHECIMENTO & EDUCAÇÃO                                                ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Wikipedia                                                                  │
# │  ├─ Enciclopédia livre                                                      │
# │  ├─ 📍 https://www.mediawiki.org/wiki/API:Main_page                         │
# │  └─ 💰 GRATUITO (sem autenticação)                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
WIKIPEDIA_API_URL=https://pt.wikipedia.org/w/api.php

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Wolfram Alpha                                                              │
# │  ├─ Computação de conhecimento                                              │
# │  └─ 📍 https://products.wolframalpha.com/api/                               │
# └─────────────────────────────────────────────────────────────────────────────┘
WOLFRAM_APP_ID=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  arXiv                                                                      │
# │  ├─ Papers científicos (preprints)                                          │
# │  └─ 📍 https://arxiv.org/help/api/                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
ARXIV_API_URL=http://export.arxiv.org/api

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Semantic Scholar                                                           │
# │  ├─ Papers científicos com AI                                               │
# │  └─ 📍 https://www.semanticscholar.org/product/api                          │
# └─────────────────────────────────────────────────────────────────────────────┘
SEMANTIC_SCHOLAR_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  OpenLibrary                                                                │
# │  ├─ Livros e informações bibliográficas                                     │
# │  ├─ 📍 https://openlibrary.org/developers/api                               │
# │  └─ 💰 GRATUITO                                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
OPENLIBRARY_API_URL=https://openlibrary.org



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   ⚖️  JURÍDICO & COMPLIANCE                                                  ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  JusBrasil (Brasil)                                                         │
# │  ├─ Jurisprudência e legislação                                             │
# │  └─ 📍 https://www.jusbrasil.com.br/api                                     │
# └─────────────────────────────────────────────────────────────────────────────┘
JUSBRASIL_API_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Planalto (Legislação Federal)                                              │
# │  └─ 📍 http://www.planalto.gov.br/                                          │
# └─────────────────────────────────────────────────────────────────────────────┘
PLANALTO_API_URL=http://www.planalto.gov.br

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Diário Oficial da União                                                    │
# │  └─ 📍 https://www.in.gov.br/                                               │
# └─────────────────────────────────────────────────────────────────────────────┘
DOU_API_URL=https://www.in.gov.br/web/dou



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   ��  SEGURANÇA & AUTENTICAÇÃO                                               ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  JWT (Autenticação Interna)                                                 │
# │  └─ 🔧 Gerar com: openssl rand -hex 32                                      │
# └─────────────────────────────────────────────────────────────────────────────┘
JWT_SECRET=
JWT_EXPIRES_MIN=1440

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Usuários Admin                                                             │
# │  └─ Separados por vírgula                                                   │
# └─────────────────────────────────────────────────────────────────────────────┘
ADMIN_USERS=admin

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Basic Auth (opcional)                                                      │
# └─────────────────────────────────────────────────────────────────────────────┘
BASIC_AUTH_USERNAME=
BASIC_AUTH_PASSWORD=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Clerk                                                                      │
# │  ├─ Auth as a Service                                                       │
# │  └─ 📍 https://dashboard.clerk.com/                                         │
# └─────────────────────────────────────────────────────────────────────────────┘
CLERK_SECRET_KEY=
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Auth0                                                                      │
# │  └─ 📍 https://manage.auth0.com/                                            │
# └─────────────────────────────────────────────────────────────────────────────┘
AUTH0_SECRET=
AUTH0_BASE_URL=
AUTH0_ISSUER_BASE_URL=
AUTH0_CLIENT_ID=
AUTH0_CLIENT_SECRET=



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🐳  DOCKER & INFRAESTRUTURA                                                ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Servidor Backend                                                           │
# └─────────────────────────────────────────────────────────────────────────────┘
AGENTOS_HOST=0.0.0.0
AGENTOS_PORT=8000

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  CORS                                                                       │
# │  └─ Origens permitidas (separadas por vírgula)                              │
# └─────────────────────────────────────────────────────────────────────────────┘
CORS_ALLOW_ORIGINS=http://localhost:4001,http://localhost:3000,https://agno-multi-agent.netlify.app

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Frontend (Next.js)                                                         │
# │  └─ ⚠️ NEXT_PUBLIC_* são baked no build - rebuild após alterar              │
# └─────────────────────────────────────────────────────────────────────────────┘
NEXT_PUBLIC_API_URL=http://localhost:4000
NEXT_PUBLIC_APP_NAME=Agno Multi-Agent Platform

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  ChromaDB (Vector Store)                                                    │
# └─────────────────────────────────────────────────────────────────────────────┘
CHROMA_HOST=http://chromadb:8000
CHROMA_DB_PATH=data/vectorstore

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Redis (Cache)                                                              │
# └─────────────────────────────────────────────────────────────────────────────┘
REDIS_URL=redis://redis:6379

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Embeddings                                                                 │
# └─────────────────────────────────────────────────────────────────────────────┘
EMBEDDING_PROVIDER=openai
OPENAI_EMBED_MODEL=text-embedding-3-large



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   ⚙️  CONFIGURAÇÕES DA APLICAÇÃO                                             ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Modelo Padrão                                                              │
# │  └─ Provedores: openai | anthropic | groq | google                          │
# └─────────────────────────────────────────────────────────────────────────────┘
DEFAULT_MODEL_PROVIDER=groq
DEFAULT_MODEL_ID=llama-3.3-70b-versatile

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Flow Studio                                                                │
# └─────────────────────────────────────────────────────────────────────────────┘
FLOW_STUDIO_ENABLED=true

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Rate Limiting                                                              │
# └─────────────────────────────────────────────────────────────────────────────┘
RATE_LIMIT_ENABLED=true
RATE_LIMIT_DEFAULT=100
RATE_LIMIT_WINDOW_SECONDS=60
RATE_LIMIT_AUTH=10
RATE_LIMIT_AGENTICS=30
RATE_LIMIT_RAG_QUERY=20
RATE_LIMIT_RAG_INGEST=5

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Database Local                                                             │
# └─────────────────────────────────────────────────────────────────────────────┘
DEFAULT_DB_FILE=data/databases/agents.db
DATABASE_URL=sqlite:///data/databases/agents.db
AUDIT_DB_PATH=data/databases/audit.db
AUDIT_LOG_FILE=data/logs/audit.jsonl

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  Debug & Logs                                                               │
# └─────────────────────────────────────────────────────────────────────────────┘
DEBUG=false
LOG_LEVEL=INFO



# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   🦟  API TECHDENGUE (Projeto Específico)  ✅ CONFIGURADA                    ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │  TechDengue API                                                             │
# │  ├─ Backend do projeto TechDengue Dashboard                                 │
# │  ├─ 📍 Hospedado em Koyeb                                                   │
# │  │                                                                          │
# │  │  🔧 FUNCIONALIDADES:                                                     │
# │  │  • Dados de casos de dengue por município                                │
# │  │  • Integração com InfoDengue                                             │
# │  │  • Alertas e notificações                                                │
# │  │  • Análise temporal e geoespacial                                        │
# │  └─────────────────────────────────────────────────────────────────────────│
# └─────────────────────────────────────────────────────────────────────────────┘
NEXT_PUBLIC_API_BASE_URL="https://tense-fallon-aeroeng-b5d4fc17.koyeb.app/api"
NEXT_PUBLIC_API_TIMEOUT="30000"



# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                                                                              ┃
# ┃   📝 NOTAS IMPORTANTES                                                       ┃
# ┃                                                                              ┃
# ┃   1. ⚠️  NUNCA commite este arquivo no Git                                   ┃
# ┃   2. 📁 Use .gitignore para proteger arquivos .env*                          ┃
# ┃   3. 🔄 Rotacione chaves periodicamente (segurança)                          ┃
# ┃   4. 🔐 Para produção, use secrets management (Vault, AWS Secrets)           ┃
# ┃   5. ✅ Variáveis vazias = integração desabilitada (não causa erro)          ┃
# ┃                                                                              ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
