# Índice — Documentação do Núcleo Licitações

- Doc 01 — `docs/_aplicações/LICITACOES_OVERVIEW.md`
- Doc 02 — `docs/_aplicações/SCHEMAS_LICITACOES.md`
- Doc 03 — `docs/_aplicações/ARQUITETURA_E_PASTAS_LICITACOES.md`
- Doc 04 — `docs/_aplicações/TOOLS_E_COLETA_LICITACOES.md`
- Doc 05 — `docs/_aplicações/AGENTES_E_ORQUESTRACAO_LICITACOES.md`
- Doc 06 — `docs/_aplicações/FLOWS_E_UI_FLOW_STUDIO.md`
- Doc 07 — `docs/_aplicações/TESTES_E_VALIDACAO_LICITACOES.md`
- Doc 08 — `docs/_aplicações/DEPLOY_E_OPERACAO_LICITACOES.md`
- Doc 09 — `docs/_aplicações/METODOLOGIA_IMPLEMENTACAO_AGENTES_E_WORKFLOWS_LICITACOES.md`
- **TODO** — `docs/_aplicações/TODO_LICITACAO.md` (guia de implementação)
