# ARCHITECTURE — Movido

> **Documento canônico:** veja [arquitetura/](./arquitetura/) (diagramas C4), [operacao/convencoes.md](./operacao/convencoes.md) e [adr_v2/](./adr_v2/)

> **Histórico (versão arquivada):** [\_archive/2024-12-16/ARCHITECTURE.md](./_archive/2024-12-16/ARCHITECTURE.md)

Este arquivo é mantido como **stub de compatibilidade**. O conteúdo oficial foi consolidado nos documentos acima.
