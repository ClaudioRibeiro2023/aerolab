# ROLES_E_ACESSO — Movido

> **Documento canônico:** [seguranca/rbac.md](./seguranca/rbac.md)

> **Ver também:** [contratos-integracao/auth.md](./contratos-integracao/auth.md)

> **Histórico (versão arquivada):** [\_archive/2024-12-16/ROLES_E_ACESSO.md](./_archive/2024-12-16/ROLES_E_ACESSO.md)

Este arquivo é mantido como **stub de compatibilidade**. O conteúdo oficial foi consolidado nos documentos acima.
