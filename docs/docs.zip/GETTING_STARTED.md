# GETTING_STARTED — Movido

> **Documento canônico:** [operacao/setup-local.md](./operacao/setup-local.md)

> **Histórico (versão arquivada):** [\_archive/2024-12-16/GETTING_STARTED.md](./_archive/2024-12-16/GETTING_STARTED.md)

Este arquivo é mantido como **stub de compatibilidade**. Para o passo a passo atualizado, use o documento canônico.
