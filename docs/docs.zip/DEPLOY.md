# DEPLOY — Movido

> **Documento canônico:** [operacao/deploy.md](./operacao/deploy.md)

Este arquivo é mantido como **stub de compatibilidade**. O conteúdo oficial foi consolidado no documento canônico acima.
