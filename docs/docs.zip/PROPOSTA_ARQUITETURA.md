# PROPOSTA_ARQUITETURA — Movido para histórico

> **Histórico (arquivo arquivado):** [\_archive/2024-12-16/PROPOSTA_ARQUITETURA.md](./_archive/2024-12-16/PROPOSTA_ARQUITETURA.md)

Este documento é mantido como **stub de compatibilidade**. Ele representa um artefato histórico de planejamento.

Para o backlog atual, veja:

- [docs/\_backlog/todo.md](./_backlog/todo.md)
- [docs/\_backlog/README.md](./_backlog/README.md)
